#IOC - IP_validation_script_1.0

$url='https://www.virustotal.com/vtapi/v2/file/report?apikey=<API Key>&resource='

$Array=@()
$outputHash= '/<File path>/hash.json' 
$validatedhash='/<File path>/validatedhash.csv'
$hash= Import-Csv "/<File path>/hash.csv"

Foreach ($line in $hash)
{
$apiurl="$($url)$($line.hash)"
Invoke-WebRequest -Method 'POST' -Uri $apiurl -OutFile $outputHash

$json=Get-Content $OutputHash | Out-String | ConvertFrom-Json

$result = New-Object PSObject

$result | add-member -membertype NoteProperty -name "Hash" -Value $Line.hash
$result | add-Member -membertype NoteProperty -name "Symantec Detection" -Value $json.scans.Symantec.detected
$Array +=$result
}
$Array | Export-Csv -Path $validatedhash -NoTypeInformation
