$OutputURL='/<filepath>/url.json'
$validatedip='/<filepath>/validatedip.csv'

$IP=Import-Csv "/<filepath>/ip.csv"


Foreach ($line in $IP)
{
$querystring = @{
    "ipAddress" = $($line.IP)
    "maxAgeInDays"= "90"
} |  ConvertTo-Json 

$headers = @{
    "Accept" = "application/json"
    "Key" = "<API key>"
}

Invoke-WebRequest -Uri https://api.abuseipdb.com/api/v2/check -Body $querystring  -Header $headers -ContentType 'application/json; charset=utf-8' -OutFile $OutputURL

$json=Get-Content $OutputURL | Out-String | ConvertFrom-Json

$result = New-Object PSObject

$result | add-member -membertype NoteProperty -name "IP Address" -Value $Line.ip
$result | add-Member -membertype NoteProperty -name "Whitelisted" -Value $json.data.isWhitelisted
$result | add-Member -membertype NoteProperty -name "Confidence Score" -Value $json.data.abuseConfidenceScore
$result | add-Member -membertype NoteProperty -name "Last Reported Date" -Value $json.data.lastReportedAt

$Array +=$result
}
$Array | Export-Csv -Path $validatedip -NoTypeInformation
